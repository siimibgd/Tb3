#!/usr/bin/env python3

import cv2
import numpy as np
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import tensorflow as tf
import tensorflow_hub as hub

class ObjectDetectorML:
    def __init__(self):
        self.bridge = CvBridge()

        # Load pre-trained model from TensorFlow Hub
        PATH_TO_MODEL = 'https://tfhub.dev/tensorflow/efficientdet/d0/1'  # Change to the desired EfficientDet version
        self.detect_fn = hub.load(PATH_TO_MODEL)

        # ROS image subscriber
        self.image_sub = rospy.Subscriber('/camera/rgb/image_raw', Image, self.image_callback)

    def image_callback(self, msg):
        cv_image = self.bridge.imgmsg_to_cv2(msg, 'bgr8')

        # Convert image to RGB
        input_tensor = tf.convert_to_tensor([cv_image])
        detections = self.detect_fn(input_tensor)

        # Identify green trash cans
        detected_classes = detections['detection_classes'][0].numpy().astype(np.int32)
        detected_boxes = detections['detection_boxes'][0].numpy()
        detected_scores = detections['detection_scores'][0].numpy()

        green_trash_can_indices = [i for i in range(len(detected_classes)) if detected_classes[i] == 44 and detected_scores[i] > 0.5]

        # Draw bounding boxes around detected green trash cans
        for idx in green_trash_can_indices:
            box = detected_boxes[idx]
            y_min, x_min, y_max, x_max = box
            x_min = int(x_min * cv_image.shape[1])
            x_max = int(x_max * cv_image.shape[1])
            y_min = int(y_min * cv_image.shape[0])
            y_max = int(y_max * cv_image.shape[0])
            cv2.rectangle(cv_image, (x_min, y_min), (x_max, y_max), (0, 255, 0), 2)

        cv2.imshow('Object Detection', cv_image)
        cv2.waitKey(1)

if __name__ == '__main__':
    rospy.init_node('object_detector_ml', anonymous=True)
    detector = ObjectDetectorML()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        cv2.destroyAllWindows()


