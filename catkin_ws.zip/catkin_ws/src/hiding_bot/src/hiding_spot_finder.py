#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import Image, LaserScan
from cv_bridge import CvBridge
import cv2
from geometry_msgs.msg import Twist
from std_msgs.msg import Bool

class HideAndSeekRobot:
    def __init__(self):
        rospy.init_node('hide_and_seek_robot', anonymous=True)

        self.bridge = CvBridge()

        # Subscribe to the robot's camera topic
        self.image_sub = rospy.Subscriber('/camera/rgb/image_raw', Image, self.image_callback)

        # Subscribe to the laser scan topic
        self.scan_sub = rospy.Subscriber('/scan', LaserScan, self.scan_callback)

        # Publish twist commands to control the robot
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

        # Publish flag to indicate hiding mode
        self.hide_mode_pub = rospy.Publisher('/hide_mode', Bool, queue_size=1)

        self.sphere_detected = False  # Flag to indicate sphere detection
        self.hide_mode = False  # Flag to indicate hiding mode
        self.scan_data = None  # Variable to store laser scan data

    def image_callback(self, data):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(data, 'bgr8')
        except Exception as e:
            print(e)
            return

        # Convert the image to grayscale
        gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)

        # Apply GaussianBlur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)

        # Use HoughCircles to detect circles (spheres)
        circles = cv2.HoughCircles(blurred, cv2.HOUGH_GRADIENT, dp=1, minDist=2, param1=50, param2=30, minRadius=5, maxRadius=1000)

        if circles is not None:
            print("Sphere detected")
            # Stop the robot if a sphere is detected
            self.stop_robot()
            # Set the sphere detection flag
            self.sphere_detected = True

            if not self.hide_mode:
                # Start searching for a wall only if not already in hiding mode
                self.search_for_wall()

    def scan_callback(self, scan_data):
        # Store laser scan data for later use
        self.scan_data = scan_data

        # Process laser scan data if needed
        # For simplicity, we'll just print the range to the closest obstacle
        closest_obstacle_distance = min(scan_data.ranges)
        print("Closest obstacle distance:", closest_obstacle_distance)

        # You can implement more sophisticated wall detection using laser data here
        # For now, let's use a simple condition to check if there is a wall (distance less than 0.5 meters)

        if closest_obstacle_distance < 0.5 and self.sphere_detected and not self.hide_mode:
            # If a wall is detected, stop the robot and move forward behind the wall
            self.stop_robot()
            self.move_behind_wall()

    def stop_robot(self):
        twist_msg = Twist()
        self.cmd_vel_pub.publish(twist_msg)

    def go_straight(self):
        twist_msg = Twist()
        twist_msg.linear.x = 0.2  # Set a forward linear velocity
        self.cmd_vel_pub.publish(twist_msg)

    def turn_for_duration(self, duration):
        # Turn around for a fixed duration (anti-clockwise)
        twist_msg = Twist()
        twist_msg.angular.z = 0.5  # Set an angular velocity for turning
        start_time = rospy.get_time()

        while rospy.get_time() - start_time < duration:
            self.cmd_vel_pub.publish(twist_msg)

        # Stop the robot after turning
        self.stop_robot()

    def search_for_wall(self):
        # Start searching for a wall by moving forward continuously
        twist_msg = Twist()
        twist_msg.linear.x = 0.2  # Set a forward linear velocity

        # Set the hiding mode flag
        self.hide_mode = True
        self.hide_mode_pub.publish(Bool(self.hide_mode))

        while not rospy.is_shutdown() and self.sphere_detected:
            self.cmd_vel_pub.publish(twist_msg)

            # Check if a wall is detected (distance less than 0.5 meters)
            if min(self.scan_data.ranges) < .5:
                # If a wall is detected, stop the robot and move forward behind the wall
                self.stop_robot()
                self.move_behind_wall()
                break

    def move_behind_wall(self):
        # Move the robot behind the wall (you need to implement this part based on your robot's capabilities)
        # For simplicity, we'll assume the robot moves forward for a fixed duration
        forward_duration = 4.0  # Adjust the duration as needed

        twist_msg = Twist()
        twist_msg.linear.x = 0.2  # Set a forward linear velocity
        start_time = rospy.get_time()

        while rospy.get_time() - start_time < forward_duration:
            self.cmd_vel_pub.publish(twist_msg)

        # Stop the robot after moving behind the wall
        self.stop_robot()

    def run(self):
        # Wait for connections to be established
        rospy.sleep(1)

        # Start the robot moving in a straight line
        self.go_straight()
        rospy.spin()

if __name__ == '__main__':
    try:
        hide_and_seek_robot = HideAndSeekRobot()
        hide_and_seek_robot.run()
    except rospy.ROSInterruptException:
        pass
